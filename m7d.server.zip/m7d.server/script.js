// Sidebar toggle (left)
function toggleSidebar(force){
  const sb = document.getElementById('sidebar');
  const ov = document.getElementById('overlay');
  if(!sb || !ov) return;
  if (force === undefined) sb.classList.toggle('show'); else if (force) sb.classList.add('show'); else sb.classList.remove('show');
  if(sb.classList.contains('show')) ov.classList.add('show'); else ov.classList.remove('show');
}
window.toggleSidebar = toggleSidebar;

document.addEventListener('click', (e)=>{
  const ov = document.getElementById('overlay');
  if(ov && ov.classList.contains('show') && e.target === ov) toggleSidebar(false);
});

// Accordion
document.addEventListener('DOMContentLoaded', ()=>{
  document.querySelectorAll('.acc-head').forEach(head=>{
    head.addEventListener('click', ()=>{
      const item = head.parentElement;
      const body = item.querySelector('.acc-body');
      if(item.classList.contains('open')){
        item.classList.remove('open');
        body.style.height = 0;
      } else {
        // close others
        document.querySelectorAll('.acc-item.open').forEach(sib=>{
          sib.classList.remove('open');
          sib.querySelector('.acc-body').style.height = 0;
        });
        item.classList.add('open');
        body.style.height = body.scrollHeight + 'px';
      }
    });
  });

  // Apply form (activation only)
  const form = document.getElementById('applyForm');
  if(form){
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      const name = document.getElementById('app_name').value.trim();
      const dc = document.getElementById('app_dc').value.trim();
      const age = document.getElementById('app_age').value.trim();
      const story = document.getElementById('app_story').value.trim();
      const agree = document.getElementById('app_agree').checked;

      if(!name || !dc || !age || !story || !agree){
        alert('الرجاء تعبئة جميع الحقول والموافقة على التعليمات.');
        return;
      }

      // story length validation (approx lines)
      const lines = story.split('\n').filter(Boolean).length;
      // allow single-paragraph stories but check char length as fallback
      if(story.length < 150){
        if(!confirm('قصة قصيرة جداً. هل تريد المتابعة؟')) return;
      }

      const key = 'mythic_activation_apps';
      const arr = JSON.parse(localStorage.getItem(key) || '[]');
      arr.push({
        id: 'APP' + Date.now(),
        name, dc, age, story, status: 'pending', created: new Date().toISOString()
      });
      localStorage.setItem(key, JSON.stringify(arr));
      document.getElementById('applyMsg').style.display = 'block';
      setTimeout(()=> document.getElementById('applyMsg').style.display = 'none', 2200);
      form.reset();
      updateAppsCount();
      toggleSidebar(false);
    });
  }

  updateAppsCount();
});

// update apps count
function updateAppsCount(){
  const el = document.getElementById('appsCount');
  if(!el) return;
  const arr = JSON.parse(localStorage.getItem('mythic_activation_apps') || '[]');
  el.innerText = arr.length;
}
